Loopy Cuts: Practical Feature-Preserving Block Decomposition for Strongly Hex-Dominant Meshing
Submission id: 514

This directory contains hexmeshes produced with our algorithm as well as related images.
Hybrid meshes are not included as we are neither using a standard format for them, for we are aware of a standard visualisation tool.

There are two directories for CAD and organic models, respectively.

For each model we provide:
model.mesh file: hexahedral mesh that can be visualised in https://www.hexalab.net/
model.png file: screenshot of the mesh
model_sing.png: screenshot of the singularities inside the mesh


  
